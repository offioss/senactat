# windowselinux 
Instalação Notebook Itautec 
